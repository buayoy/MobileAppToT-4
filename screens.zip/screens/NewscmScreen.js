import React, { Component } from 'react';
import { Platform, StyleSheet, Text, View, Image, TouchableHighlight, WebView, Dimensions, ScrollView } from 'react-native';
import HTML from 'react-native-render-html';
import Icon from 'react-native-vector-icons/Ionicons';
import axios from 'axios';
import ResponsiveImage from 'react-native-responsive-image';
import PhotoGrid from '../PhotoGrid'
import ImageView from 'react-native-image-view';


import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
  listenOrientationChange as loc,
  removeOrientationListener as rol
} from 'react-native-responsive-screen';


export default class NewscmScreen extends Component {




  state = {
    data: [],
    images: [],
    modalVisible:true,
    popupimg:false,
    selectedImg:null,
  }




  static navigationOptions = {

    title: 'รายละเอียด',
    headerStyle: {
      backgroundColor: '#00802b',
      textAlign: 'center',
    },
    headerTintColor: '#fff',
    headerTitleStyle: {
      fontWeight: 'bold',
    },

  };


  async getData(id) {
    // alert(id);

      const response = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/newscm/detail/' + id, {
        params: {
          course_id: id
        }
      });

      const responsereplyImage = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/newscm/detail/images/' + id);

      this.setState({ data: response.data });
      this.setState({
        images: responsereplyImage.data.map((i, index) => {
            let urlToImage = 'http://1.179.246.102/npcr_admin_api/public/upload/imagenewscm/' + i.filename;

            return { uri: urlToImage, index: index };
        })
    });
      // alert(JSON.stringify(response.data));

  }

  rendermodalimage(uri, source) {
      // alert(source.index);
      this.setState({ 
          popupimg: false,
          selectedImg: null,
      });
      this.setState({ 
          popupimg: true,
          selectedImg: source.uri ,
      });
  }

  componentDidMount() {
    const id = this.props.navigation.getParam('id', 0);
    this.getData(id);
  }


  render() {
    const images = [
        {
            source: {
                uri: this.state.selectedImg,
            },
            title: 'img',
            width: 806,
            height: 720,
        },
    ];
    return (
      //   <WebView
      //   source={{uri: this.props.navigation.getParam('url','')}}
      //   style={{marginTop: 0}}
      //   useWebkit={true}
      // />

      <View style={styles.container}>
        <ScrollView>
          <View style={{ backgroundColor: 'white' }}>
            <ResponsiveImage source={{ uri: 'http://1.179.246.102/npcr_admin_api/public/upload/Imagenewscm/'+this.state.data.headlines }} resizeMode='stretch' style={{ height: hp('30%') }} />
          </View>
          <Text style={styles.header}>
            {this.state.data.news_cm_name}
          </Text>
          <View>
            <Text style={styles.detail}>{this.state.data.news_cm_detail} </Text>
          </View>
          {
              (this.state.popupimg == true) ? (
                  <ImageView
                      images={images}
                      imageIndex={0}
                      isVisible={true}
                      renderFooter={(currentImage) => (<View><Text>My footer</Text></View>)}
                  />
              ) : (
                  <Text></Text>            
              )
          }
          <View style={{ alignItems: 'center', marginRight: 7.5 }}>
              {/* <PhotoGrid source={this.state.images} onPressImage={(uri, source) => this.rendermodalimage(uri, source)} /> */}
          </View>
        </ScrollView>
      </View>


    );
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    marginLeft: wp('5%'),
    marginTop: hp('3%'),
    marginRight: wp('2%'),
    fontSize: hp('2.3%'),
    fontWeight: 'bold',
  },
  detail: {
    marginLeft: 15,
    marginTop: 20,
    marginRight: 20,
    fontSize: hp('2')
  }
});
