import React, { Component } from 'react';
import {
    Image,Picker,Alert,Linking, AppRegistry, Platform, StyleSheet, Text,
  TouchableHighlight, TouchableOpacity, TouchableNativeFeedback,
  TouchableWithoutFeedback, View ,AsyncStorage,TextInput,ScrollView
} from 'react-native';
// import Ionicons from 'react-native-vector-icons/Ionicons';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
    listenOrientationChange as loc,
    removeOrientationListener as rol
  } from 'react-native-responsive-screen';

import HeaderButtons, { HeaderButton, Item } from 'react-navigation-header-buttons';
import { FormLabel, FormInput, FormValidationMessage, Button ,Card } from 'react-native-elements'
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'

import axios from 'axios';
import Icon from 'react-native-vector-icons/Ionicons';
import Logo from '../components/logo/index'
import { Dropdown } from 'react-native-material-dropdown';
import ImageSelecter from 'react-native-image-picker';
import { NavigationActions } from 'react-navigation';

const backAction = NavigationActions.back({
    key: 'Home',
  });

  const navigateAction = NavigationActions.navigate({
    routeName: 'Home',
  
    params: {},
  
    action: NavigationActions.navigate({ routeName: 'Home' }),
  });

const width = '100%';
const IoniconsHeaderButton = passMeFurther => (
    <HeaderButton {...passMeFurther} IconComponent={Icon} iconSize={30} color="white" />
  
  );
export default class Verifyscreen extends Component {
    constructor(props){

        super(props);
        // this.mCredentail = {credentail :{phone2:this.state.phonenumber , citizen2:this.state.citizenID }}
        this.state={
            lastRefresh: Date(Date.now()).toString(),
        
        
        
          // This is our Default number value
          NumberHolder : 1 ,
          citizenID:'',
          phonenumber:'',
          text:'',
          loading: true,
          verify:'',
          email: '',
    password: '',
        }
        this.refreshScreen = this.refreshScreen.bind(this)
      
        
      }
 
      static navigationOptions  = ({navigation}) => {
        // const { params = {} } = navigation.state;
        // const params = navigation.getParam('checklogin')
        // this.state.user
        // alert(params)
        return {
          headerTitle: <Logo/>,
          headerLeft: ( <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}
            >
          //     {/* <Item 
          //     title="menu" iconName="ios-exit" 
              
          //       onPress={()=>{
          //       // Alert.alert('test')
          //       AsyncStorage.removeItem('user')
          //       AsyncStorage.removeItem('phone')
          //       AsyncStorage.removeItem('name')
          //       AsyncStorage.removeItem('lastname')
          //       AsyncStorage.removeItem('province')
          //       AsyncStorage.removeItem('district')
          //       AsyncStorage.removeItem('subdistrict')
          //       AsyncStorage.removeItem('village')
          //       // AsyncStorage.removeItem('district')
          //       // this.setState({refreshing: true});
          //       // navigation.navigate('Home')
          //     }}
               
          //     /> */}
            </HeaderButtons>
          ),
          //<NavIcon action={() => AsyncStorage.removeItem('user')} />
             
            
            // headerRight: (
            //   <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}>
            //     {
            //     <Item 
            //     title="register" 
            //     iconName= 'ios-create'
            //     //"ios-person" 
            //     onPress={() => navigation.navigate('EditProfile')} 
            //     />
            //     }
            //   </HeaderButtons>
            // ),
              
          headerStyle: {
              backgroundColor: '#006600',
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
              textAlign: 'center',
              flex:1
            },
          }
        };
        componentWillMount(){
            this.refreshScreen();
        }
 

  _Verify=async()=>{
      try{
       
        if(this.state.phonenumber.length == 10 && this.state.citizenID.length == 13){
        const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/otp4/insert',{
            otp_PhoneNumber:this.state.phonenumber
        });
                AsyncStorage.setItem('text',JSON.stringify(response.data));
                
                let RandomNumber = Math.floor(Math.random() * 9999) + 1 ;
                this.setState({
                text : RandomNumber
                })
                //  Alert.alert(JSON.stringify(this.state.text))
                const url = await axios.post('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&phonenumber='+this.state.phonenumber+'&text='+this.state.text+'&lang=en')
            
        }else if(this.state.phonenumber.length == 10 && this.state.citizenID.length < 13){
        Alert.alert('กรอกเลขบัตรประจำตัวประชาชนให้ครบถ้วน')
        }else if(this.state.phonenumber.length < 10 && this.state.citizenID.length == 13){
        Alert.alert('กรอกหมายเลขโทรศัพท์มือถือให้ครบถ้วน')
        }else if(this.state.phonenumber.length < 10 && this.state.citizenID.length < 13){
        Alert.alert('กรอกข้อมูลให้ครบถ้วน')
        }

      }catch{

      }
  
  }
  _Verify3=async()=>{
    const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/otp3/insert',{
        otp_PhoneNumber:this.state.phonenumber
    });
    let RandomNumber = Math.floor(Math.random() * 9999) + 1 ;
    this.setState({
    text : RandomNumber
    })
    const url = await axios.post('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&phonenumber='+this.state.phonenumber+'&text='+this.state.text+'&lang=en')


  }

 
  componentDidMount(){
    this.refreshScreen();
    
  }
 _Verify2=async()=>{
   try{
  if(this.state.verify == this.state.text){
    const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/checkphone?save_phone='+this.state.phonenumber,{
  });
    if(response.data.message == 'notsame'){
        Alert.alert('หมายเลขโทรศัพท์มือถือนี้ใช้งานได้')
        // this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)
       
        this.props.navigation.navigate('AddProfile', {credentail:{phone2:this.state.phonenumber , citizen2:this.state.citizenID}})
    }else{
        // Alert.alert("เบอร์โทรศัพท์ซ้ำในระบบ")
        Alert.alert('หมายเลขโทรศัพท์มือถือ '+this.state.phonenumber+' ถูกใช้ไปแล้ว')
        this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)
    }

  }else{
    Alert.alert('กรอกรหัส OTP ไม่ถูกต้อง')
  }
  
}catch(error){
  console.log(error)
}

}


refreshScreen() {
    this.setState({ lastRefresh: Date(Date.now()).toString() })
  }
  render() {
    
    return (
    
      <View style={styles.container}>
      <View style={{justifyContent:'center',alignItems:'center',flexDirection:'column'}}>
      <Icon  style={{borderWidth:0 , borderColor:"black"}} name="ios-person-add" size={80} color="#006600"  />
      <Text style={{fontWeight:'bold', fontSize:30 ,color:'#006600',marginTop:-15,marginBottom:20 ,fontFamily: "Prompt-Light" }}>สมัครสมาชิก</Text>
      </View>
      <View style={{flex:1}}>
      {
        this.state.text ? (
          
          <View>
           <Card containerStyle={{padding: 0 ,borderRadius:7 , marginBottom:10 ,borderColor:'#7CFC00'}} >
          <Text style={{fontSize:20,color:'#006600',marginLeft:10,marginBottom:10 ,marginTop:10 ,fontFamily: "Prompt-Light"}}>ข้อมูลส่วนตัว</Text>
          <Text style={{fontSize:14,color:'#006600',marginLeft:10,marginBottom:2 , fontFamily: "Prompt-Light"}}>เลขบัตรประจำตัวประชาชน: {this.state.citizenID}</Text>
          <Text style={{fontSize:14,color:'#006600',marginLeft:10 , fontFamily: "Prompt-Light"}}  >กรอกรหัส OTP ของหมายเลข: {this.state.phonenumber}</Text>
           <TextInput
           keyboardType='numeric'
           autoCapitalize={'none'}
           autoCorrect={false}
           style={styles.input}
            ref={verify => this.verify = verify}
            placeholder={'กรอกรหัส OTP ของ '+this.state.phonenumber}
            onChangeText={
              verify => this.setState({ verify })
            }
            
            // keyboardType='email-address'
          />
          <View style={{ flexDirection: 'column',justifyContent: 'space-around',marginBottom:20}}>
         <Button
           backgroundColor='#006600'
           // buttonStyle={{ marginTop: 30 }}
           buttonStyle={{ marginTop: 30 ,borderRadius:10  }}
          //  large
           title={'ยืนยันรหัส OTP '}
           fontFamily= "Prompt-Light"
          onPress={this._Verify2}
          
           //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
         />
        <View style={{flexDirection:'row'}}>
         <Button
           backgroundColor='#006600'
           
          //  color='#006600'
           // buttonStyle={{ marginTop: 30 }}
           buttonStyle={{ marginTop: 30 ,borderRadius:10 , borderWidth: 1 ,borderColor:'#7CFC00' }}          //  large
           title={'ขอรหัสยืนยัน OTP อีกครั้ง'}
           backgroundColor='#FFFFFF'
           color="#006600"
           fontFamily= "Prompt-Light"
          onPress={this._Verify3}
           //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
         />
         <Button
           backgroundColor='#006600'
           
          //  color='#006600'
           // buttonStyle={{ marginTop: 30 }}
           buttonStyle={{ marginTop: 30 ,borderRadius:10 , borderWidth: 1 ,borderColor:'#7CFC00' }}          //  large
           title={'ยกเลิก'}
           backgroundColor='#FFFFFF'
           color="#006600"
           fontFamily= "Prompt-Light"
    onPress={()=>this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)}
   
           //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
         />
         </View>
         </View>
         </Card>
         </View>
        
        ):(
          <KeyboardAwareScrollView>
            <Card containerStyle={{padding: 0 ,borderRadius:7 , marginBottom:10,borderColor:'#7CFC00'}} >
          <Text style={styles.labelStyle}>เลขประจำตัวประชาชน</Text>
          <TextInput
            
            ref={citizenID => this.citizenID = citizenID}
            // keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            style={styles.input}
            maxLength = {13}
            placeholder='กรอกเลขบัตรประจำตัวประชาชน'
            onChangeText={
                citizenID => this.setState({ citizenID })
            }
            // keyboardType='email-address'
            keyboardType='numeric'
          />
            
          <Text style={styles.labelStyle}>หมายเลขโทรศัพท์มือถือ</Text>
          <TextInput
           
            ref={phonenumber => (this.phonenumber = phonenumber)}
            //keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            maxLength = {10}
            
            style={{height: 50,
              width: '90%',
              marginTop: 10,
              marginLeft:18,
              padding: 4,
              borderRadius: 5,
              fontSize: 18,
              color:'#006600',
              fontFamily: "Prompt-Light",
              borderWidth: 1,
              borderColor: '#48bbec33'}}
            placeholder="กรอกหมายเลขโทรศัพท์มือถือ"
            onChangeText={phonenumber => this.setState({ phonenumber })}
            keyboardType='numeric'
            // secureTextEntry={true}
          />
          
          
           <View style={{ flexDirection:'row' ,flex:1 ,justifyContent:'center' ,marginBottom:20}}>
          <Button
            backgroundColor='#006600'
            buttonStyle={{ marginTop: 30 ,borderRadius:10 ,width:110  }}
            // large
            title='ยืนยัน'
            fontFamily= "Prompt-Light"
            onPress={  this._Verify }
           
            
            //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
          /><Button
          backgroundColor='#006600'
          buttonStyle={{ marginTop: 30 ,borderRadius:10,width:110 , borderWidth: 1 ,borderColor:'#7CFC00' }}
          // large
          title='ยกเลิก'
          fontFamily= "Prompt-Light"
          backgroundColor='#FFFFFF'
          color="#006600"
          onPress={()=> this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)}
         
          
          //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
        />
         </View>
         </Card>
        </KeyboardAwareScrollView>
        
        )}
        <View style={{ flexDirection: 'row',justifyContent: 'space-around',}}>
          
          
        </View>
        </View>
      </View>


    )
      
    
    ;
  }
}

export class Login2screen extends Component {
    constructor(props){

        super(props);
        // this.mCredentail = {credentail :{phone2:this.state.phonenumber , citizen2:this.state.citizenID }}
        this.state={
            lastRefresh: Date(Date.now()).toString(),
        
        
        
          // This is our Default number value
          NumberHolder : 1 ,
          citizenID:'',
          phonenumber:'',
          text:'',
          loading: true,
          verify:'',
          email: '',
    password: '',
        }
        this.refreshScreen = this.refreshScreen.bind(this)
      
        
      }
 
      static navigationOptions  = ({navigation}) => {
        // const { params = {} } = navigation.state;
        // const params = navigation.getParam('checklogin')
        // this.state.user
        // alert(params)
        return {
          headerTitle: <Logo/>,
          headerLeft: ( <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}
            >
          //     {/* <Item 
          //     title="menu" iconName="ios-exit" 
              
          //       onPress={()=>{
          //       // Alert.alert('test')
          //       AsyncStorage.removeItem('user')
          //       AsyncStorage.removeItem('phone')
          //       AsyncStorage.removeItem('name')
          //       AsyncStorage.removeItem('lastname')
          //       AsyncStorage.removeItem('province')
          //       AsyncStorage.removeItem('district')
          //       AsyncStorage.removeItem('subdistrict')
          //       AsyncStorage.removeItem('village')
          //       // AsyncStorage.removeItem('district')
          //       // this.setState({refreshing: true});
          //       // navigation.navigate('Home')
          //     }}
               
          //     /> */}
            </HeaderButtons>
          ),
          //<NavIcon action={() => AsyncStorage.removeItem('user')} />
             
            
            // headerRight: (
            //   <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}>
            //     {
            //     <Item 
            //     title="register" 
            //     iconName= 'ios-create'
            //     //"ios-person" 
            //     onPress={() => navigation.navigate('EditProfile')} 
            //     />
            //     }
            //   </HeaderButtons>
            // ),
              
          headerStyle: {
              backgroundColor: '#006600',
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
              textAlign: 'center',
              flex:1
            },
          }
        };
        componentWillMount(){
            this.refreshScreen();
        }

 
  _Verify=async()=>{
      try{
        
        if(this.state.phonenumber.length == 10){
            const responsestatus = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/checkphone?save_phone='+this.state.phonenumber,{
            });
            if(responsestatus.data.message == 'same'){
        const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/otp3/insert',{

        });
        
        AsyncStorage.setItem('text',JSON.stringify(response.data));

        let RandomNumber = Math.floor(Math.random() * 9999) + 1 ;
        this.setState({
        text : RandomNumber
        })
        // Alert.alert(JSON.stringify(this.state.text));
        const url = await axios.post('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&phonenumber='+this.state.phonenumber+'&text='+this.state.text+'&lang=en')
          
    }if(responsestatus.data.message == 'notsame'){
        Alert.alert("ไม่มีหมายเลขโทรศัพท์มือถือ "+ this.state.phonenumber +" อยู่ในระบบ กรณาสมัครสมาชิกก่อนลงชื่อเข้าใช้")
    }
        
        //AsyncStorage.setItem(JSON.stringify(response.data));
      //  alert(this.state.text)
        // this.props.navigation.navigate('Otp2',{ otp: response.data });
  }else if(this.state.phonenumber.length < 10){
    Alert.alert('กรอกหมายเลขโทรศัพท์มือถือให้ครบถ้วน')
  }
      }catch{

      }
  
  }
  
  _Register = () => {
      this.props.navigation.navigate('Register')
      
  }
  componentDidMount(){
    this.refreshScreen();
  }
 _Verify2=async()=>{
   try{
   

       if(this.state.verify == this.state.text){
    const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/checkadmin?save_phone='+this.state.phonenumber);
    
    let obj={
        name:response.data.name,
        lastname:response.data.lastname
      }
      // Alert.alert(JSON.stringify(response.data.id))
      AsyncStorage.setItem('user',JSON.stringify(obj))
      AsyncStorage.setItem('phone',JSON.stringify(this.state.phonenumber))
      AsyncStorage.setItem('userid',JSON.stringify(response.data.id))
      AsyncStorage.setItem('type',JSON.stringify(response.data.type))
      
    
    this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0);
  }else{
    Alert.alert('กรอกรหัส OTP ไม่ถูกต้อง')
  }
  
}catch(error){
  console.log(error)
}

}


refreshScreen() {
    this.setState({ lastRefresh: Date(Date.now()).toString() })
  }
  render() {
    
    return (
    
      <View style={styles.container}>
      <View style={{justifyContent:'center',alignItems:'center',flexDirection:'column'}}>
      <Icon  style={{borderWidth:0 , borderColor:"black"}} name="ios-person-add" size={80} color="#006600"  />
      <Text style={{fontWeight:'bold', fontSize:30 ,color:'#006600',marginTop:-15,marginBottom:20 ,fontFamily: "Prompt-Light" }}>ลงชื่อเข้าใช้</Text>
      </View>
      <View style={{flex:1}}>
      {
        this.state.text ? (
          
          <View>
           <Card containerStyle={{padding: 0 ,borderRadius:7 , marginBottom:10 ,borderColor:'#7CFC00'}} >
          <Text style={{fontSize:20,color:'#006600',marginLeft:10,marginBottom:10 ,marginTop:10 ,fontFamily: "Prompt-Light"}}>ข้อมูลส่วนตัว</Text>
          {/* <Text style={{fontSize:14,color:'#006600',marginLeft:10,marginBottom:2 , fontFamily: "Prompt-Light"}}>เลขบัตรประจำตัวประชาชน: {this.state.citizenID}</Text> */}
          <Text style={{fontSize:14,color:'#006600',marginLeft:10 , fontFamily: "Prompt-Light"}}  >กรอกรหัส OTP ของหมายเลข: {this.state.phonenumber}</Text>
           <TextInput
           keyboardType='numeric'
           autoCapitalize={'none'}
           autoCorrect={false}
           style={styles.input}
            ref={verify => this.verify = verify}
            placeholder={'กรอกรหัส OTP ของ '+this.state.phonenumber}
            onChangeText={
              verify => this.setState({ verify })
            }
            
            // keyboardType='email-address'
          />
          <View style={{ flexDirection: 'column',justifyContent: 'space-around',marginBottom:20}}>
         <Button
           backgroundColor='#006600'
           // buttonStyle={{ marginTop: 30 }}
           buttonStyle={{ marginTop: 30 ,borderRadius:10  }}
          //  large
           title={'ยืนยันรหัส OTP '}
           fontFamily= "Prompt-Light"
          onPress={this._Verify2}
          
           //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
         />

         <Button
           backgroundColor='#006600'
           
          //  color='#006600'
           // buttonStyle={{ marginTop: 30 }}
           buttonStyle={{ marginTop: 30 ,borderRadius:10 , borderWidth: 1 ,borderColor:'#7CFC00' }}          //  large
           title={'ขอรหัสยืนยัน OTP อีกครั้ง'}
           backgroundColor='#FFFFFF'
           color="#006600"
           fontFamily= "Prompt-Light"
          onPress={this._Verify}
           //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
         />
         </View>
         </Card>
         </View>
        
        ):(
          <KeyboardAwareScrollView>
            <Card containerStyle={{padding: 0 ,borderRadius:7 , marginBottom:10,borderColor:'#7CFC00'}} >
          {/* <Text style={styles.labelStyle}>เลขประจำตัวประชาชน</Text>
          <TextInput
            
            ref={citizenID => this.citizenID = citizenID}
            // keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            style={styles.input}
            maxLength = {13}
            placeholder='กรอกเลขบัตรประจำตัวประชาชน'
            onChangeText={
                citizenID => this.setState({ citizenID })
            }
            // keyboardType='email-address'
            keyboardType='numeric'
          /> */}
            
          <Text style={styles.labelStyle}>หมายเลขโทรศัพท์มือถือ</Text>
          <TextInput
           
            ref={phonenumber => (this.phonenumber = phonenumber)}
            //keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            maxLength = {10}
            
            style={{height: 50,
              width: '90%',
              marginTop: 10,
              marginLeft:18,
              padding: 4,
              borderRadius: 5,
              fontSize: 18,
              color:'#006600',
              fontFamily: "Prompt-Light",
              borderWidth: 1,
              borderColor: '#48bbec33'}}
            placeholder="กรอกหมายเลขโทรศัพท์มือถือ"
            onChangeText={phonenumber => this.setState({ phonenumber })}
            keyboardType='numeric'
            // secureTextEntry={true}
          />
          
          
           <View style={{ flexDirection:'row' ,flex:1 ,justifyContent:'center' ,marginBottom:20}}>
          <Button
            backgroundColor='#006600'
            buttonStyle={{ marginTop: 30 ,borderRadius:10 ,width:110  }}
            // large
            title='ยืนยัน'
            fontFamily= "Prompt-Light"
            onPress={  this._Verify }
           
            
            //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
          /><Button
          backgroundColor='#006600'
          buttonStyle={{ marginTop: 30 ,borderRadius:10,width:110 , borderWidth: 1 ,borderColor:'#7CFC00' }}
          // large
          title='ยกเลิก'
          fontFamily= "Prompt-Light"
          backgroundColor='#FFFFFF'
          color="#006600"
            onPress={()=>this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)}
         
          
          //source={{uri:this.props.navigation.getParam('http://sms2.totbb.net/sms/tshell_sms_1.php?sender=MDES&'+this.state.phonenumber+'=0912312344&'+this.state.text+'lang=en','')}}
        />
         </View>
         </Card>
        </KeyboardAwareScrollView>
        
        )}
        <View style={{ flexDirection: 'row',justifyContent: 'space-around',}}>
          
          
        </View>
        </View>
      </View>


    )
      
    
    ;
  }
}

// create a component
export class AddProfile extends Component {


    static navigationOptions  = ({navigation}) => {
        // const { params = {} } = navigation.state;
        // const params = navigation.getParam('checklogin')
        // this.state.user
        // alert(params)
        return {
          headerTitle: <Logo/>,
          headerLeft: ( <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}
            >
          //     {/* <Item 
          //     title="menu" iconName="ios-exit" 
              
          //       onPress={()=>{
          //       // Alert.alert('test')
          //       AsyncStorage.removeItem('user')
          //       AsyncStorage.removeItem('phone')
          //       AsyncStorage.removeItem('name')
          //       AsyncStorage.removeItem('lastname')
          //       AsyncStorage.removeItem('province')
          //       AsyncStorage.removeItem('district')
          //       AsyncStorage.removeItem('subdistrict')
          //       AsyncStorage.removeItem('village')
          //       // AsyncStorage.removeItem('district')
          //       // this.setState({refreshing: true});
          //       // navigation.navigate('Home')
          //     }}
               
          //     /> */}
            </HeaderButtons>
          ),
          //<NavIcon action={() => AsyncStorage.removeItem('user')} />
             
            
            // headerRight: (
            //   <HeaderButtons HeaderButtonComponent={IoniconsHeaderButton}>
            //     {
            //     <Item 
            //     title="register" 
            //     iconName= 'ios-create'
            //     //"ios-person" 
            //     onPress={() => navigation.navigate('EditProfile')} 
            //     />
            //     }
            //   </HeaderButtons>
            // ),
              
          headerStyle: {
              backgroundColor: '#006600',
            },
            headerTintColor: '#fff',
            headerTitleStyle: {
              fontWeight: 'bold',
              textAlign: 'center',
              flex:1
            },
          }
        };

  state = {
     
      problemname: '',
      problemdetail: '',
      province: '',
      district: '',
      subdistrict: '',
      village: '',
      getprovince: [],
      getdistrict: [],
      getsubdistrict: [],
      getvillage: [],
      hide: false,
      user:{},
      phone:this.props.navigation.state.params.credentail.phone2,
      citizen:this.props.navigation.state.params.credentail.citizen2,
      name:'',
      lastname:'',
      imageSource:null,
      userrole:'',
      type:'ผู้ใช้งานทั่วไป',
      email:''
      }

  _Postproblem = async () => {
      const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/post', {
          problemname: this.state.problemname,
          problemdetail: this.state.problemdetail,
          province: this.state.province,
          district: this.state.district,
          subdistrict: this.state.subdistrict,
          village: this.state.village,
      });

      if (response.data.status === 'ok') {
          Alert.alert('ผลการทำงาน', response.data.message, [{ text: 'ตกลง' }]);
      } else {
          Alert.alert('ผลการทำงาน', response.data.message, [{ text: 'ตกลง' }]);
      }

  }
  async showData(){
    var Phone = await AsyncStorage.getItem("phone");
    await this.setState({ phone: Phone });
    var Citizen = await AsyncStorage.getItem("citizen");
    await this.setState({ citizen: Citizen});
    Alert.alert( this.state.phone + this.state.citizen );
   
    }

    async checkroleadmin(){
        const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/checkadmin',{
                            save_phone:this.state.phone,
                         });
        // var userRole = response.data.type
        if(response.data.phone >0 ){
            Alert.alert("หมายเลขโทรศัพท์ถูกใช้ไปแล้ว")
            // let obj={
            //     name : response.data.name,  
            //     lastname : response.data.lastname
            // }
            // //start add value to asyncstorage
            // AsyncStorage.setItem('user',JSON.stringify(obj));
            // AsyncStorage.setItem('phone',JSON.stringify(this.state.phone));
            // //end add value//
            // this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0);

        }else{
            this.getData();
        }
    }

  async getData() {
      const response = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/problem/getprovince');
      this.setState({ getprovince: response.data });
      // alert(JSON.stringify(response.data));
  }

  async getDistrict(itemValue){
      const response = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/problem/getdistrict/'+itemValue);
      this.setState({ province: itemValue,
                      getdistrict: response.data  
      });
      // Alert.alert(itemValue);  
  }

  async getSubDistrict(itemValue){
      const response = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/problem/getsubdistrict/'+itemValue);
      this.setState({ district: itemValue,
                      getsubdistrict: response.data 
      });
      // Alert.alert(itemValue);
  }

  async getVillage(itemValue){
      const response = await axios.get('http://1.179.246.102/npcr_admin_api/public/api/problem/getvillage/'+itemValue);
      this.setState({ subdistrict: itemValue,
                      getvillage: response.data 
      });
      // Alert.alert(itemValue);
  }
  
  _SaveUser = async () => {
    
       
        const {name,subdistrict,village,district,province,lastname,citizen} = this.state
        const response =  await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/post', {
          save_name: this.state.name,
          save_phone: this.state.phone,
          save_citizen:this.state.citizen,
          save_lastname:this.state.lastname,
          province: this.state.province,
          district: this.state.district,
          subdistrict: this.state.subdistrict,
          village: this.state.village,
          type:this.state.type,
          email:this.state.email
          // headlines:this.state.imageSource.uri
  
          // status: 'ยังไม่ดำเนินการ',
      });
      Alert.alert(response.data.message)
      this.props.navigation.reset([NavigationActions.navigate({ routeName: 'Home' })], 0)
      

    //Alert.alert(this.state.name+this.state.phone+this.state.citizen+this.state.lastname+this.state.province+this.state.district+this.state.subdistrict+this.state.village)
    // Alert.alert(response)

   
   

}
  getparam(){
    var params = this.props.navigation.getParam("credentail")
    const {phone,citizen} = params
  }
  componentDidMount() {
      this.checkroleadmin();
    this.getData();
      // this.showData();
      this.getparam();
     
  }
  async showVerifyData(){
   
  }
 async uploadPhoto(citizen_id) {
        // citizen_id = 2222222222222;
        // alert(citizen_id)
        // alert('In uploadPhoto ... uri = '+this.state.imageSource.uri);
         //alert('In uploadPhoto ... uri');

        const response = await axios.post('http://1.179.246.102/npcr_admin_api/public/api/saveuser/upload_image?citizen_id='+citizen_id, {
            // problem_id: problem_id,
            imageData: this.state.imageSource.uri
            
        });
        let imageurl1 = response.data.filename
        AsyncStorage.setItem('imageurl',JSON.stringify(imageurl1))
        Alert.alert(response.data.filename);

        // Alert.alert(JSON.stringify(citizen_id));
    }

    _SelectCameraRoll = () => {

        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
                skipBackup: true
            }
        };
        ImageSelecter.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled image picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else {
                // alert('response image ....')
                // const source = { uri: `data:${response.data.mime};base64,` + response.data };
                // let source = { uri: response.uri };
                this.setState({
                    imageSource: {
                        uri: 'data:image/jpeg;base64,' + response.data,
                    }
                });
                //alert(this.state.imageSource.uri);
                //this.uploadPhoto(this.state.citizen);
            }
        });
    };
  render() {
      return (
       
          <View style={styles.container}>
        
              <Text style={styles.welcome}><Icon name="ios-person" size={40} color='#00802b' />เพิ่มข้อมูลส่วนตัว</Text>
              {/* <Text style={styles.welcome}><Icon name="ios-megaphone" size={40} color='#00802b' /></Text> */}
              <View style = {styles.lineStylew1} />
              <View style = {styles.lineStylew2} />
              {this.state.neme ? (
              <KeyboardAwareScrollView>
                  
                  {/* <View style = {styles.lineStylew3} /> */}
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      2. เลือกจังหวัด
                  </FormLabel>
                  <Dropdown
                      containerStyle={{margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 ,fontFamily: "Prompt-Light" }}
                      label=''
                      ref={province => this.province = province}
                      data={this.state.getprovince}
                      onChangeText={
                          // province => this.setState({ province });
                          (itemValue, itemIndex) => this.getDistrict(itemValue)
                      }
                  />
                  <View style={this.state.hide ? {position: 'absolute', top: -200} : {}}>
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      3. เลือกอำเภอ
                  </FormLabel>
                  <Dropdown
                      containerStyle={{margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      ref={district => this.district = district}
                      data={this.state.getdistrict}
                      onChangeText={
                          (itemValue, itemIndex) => this.getSubDistrict(itemValue)
                      }
                  />
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      4. เลือกตำบล
                  </FormLabel>
                  <Dropdown
                      containerStyle={{margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      ref={subdistrict => this.subdistrict = subdistrict}
                      data={this.state.getsubdistrict}
                      onChangeText={
                          (itemValue, itemIndex) => this.getVillage(itemValue)
                      }
                  />
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      5. เลือกหมู่บ้าน
                  </FormLabel>
                  <Dropdown
                      containerStyle={{margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      ref={village => this.village = village}
                      data={this.state.getvillage}
                      onChangeText={
                          village => this.setState({ village })
                      }
                  />
                  </View>
                  <View style = {styles.lineStylew3} />
                 
                  {/* <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      7. เบอร์ติดต่อกลับ
                  </FormLabel>
                  <FormInput
                      inputStyle={{ borderColor: 'grey', marginTop: 5, borderWidth: 1 ,borderRadius: 5 }}
                      ref={email => this.email = email}
                      placeholder=''
                      onChangeText={
                          email => this.setState({ email })
                      }
                      keyboardType='email-address'
                  /> */}
                  <View style={styles.setpositionbutton}>
                      <Button
                          backgroundColor='#00802b'
                          buttonStyle={{ marginTop: 30, width: 100, borderWidth: 1, borderColor: '#00802b' ,borderRadius: 5 ,marginLeft: -2.5 ,marginRight: -2.5}}
                          // icon={{ name: 'person', type: 'font-person' }}
                          title='ยืนยัน'
                          onPress={this._SaveUser}
                      />
                      <Button
                          backgroundColor='#ffff'
                          buttonStyle={{ marginTop: 30, width: 100, borderWidth: 1, borderColor: '#00802b' ,borderRadius: 5 ,marginLeft: -2.5 ,marginRight: -2.5}}
                          // icon={{ name: 'person', type: 'font-person' }}
                          title='ยกเลิก'
                          color="#00802b"
                          onPress={() => {
                              this.props.navigation.navigate("Report_btn_step_2");
                          }}
                      />
                  </View>
              </KeyboardAwareScrollView>):(
                <View>
                  <KeyboardAwareScrollView>
            <Card containerStyle={{padding: 0 ,borderRadius:7 , marginBottom:100,borderColor:'#7CFC00'}} >
            {/* <TextInput
            
            ref={name => this.name = name}
            // keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            style={styles.input}
            maxLength = {13}
            placeholder='กรอกชื่อจริง'
            onChangeText={ name => this.setState({ name })}
            // keyboardType='email-address'
          /> */}
          {/* <Text style={styles.labelStyle}>{this.state.user.phone}</Text> */}
<Text style={styles.labelStyle}>หมายเลขโทรศัพท์ {this.state.phone}</Text>
<Text style={styles.labelStyle}>เลขบัตรประจำตัวประชาชน {this.state.citizen}</Text>
{/* <Text style={styles.labelStyle}>params  {this.state.phone}</Text> */}


          <Text style={styles.labelStyle}>ชื่อจริง</Text>
          <TextInput
            
            ref={name => this.name = name}
            // keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            style={styles.input}
            maxLength = {60}
            placeholder='กรอกชื่อจริง'                             
            onChangeText={ name => this.setState({ name })}
            // keyboardType='email-address'
          />
            
          <Text style={styles.labelStyle}>นามสกุล</Text>
          <TextInput
            ref={lastname => (this.lastname = lastname)}
            //keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            maxLength = {60}
            style={styles.input}
            placeholder="กรอกนามสกุล"
             onChangeText={lastname => this.setState({ lastname })}
            // secureTextEntry={true}
          />
          <Text style={styles.labelStyle}>อีเมล</Text>
           <TextInput
            ref={email => (this.email = email)}
            //keyboardType={'email-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            maxLength = {30}
            style={styles.input}
            placeholder="กรอกอีเมล"
             onChangeText={email => this.setState({ email })}
            keyboardType={'email-address'}

            // secureTextEntry={true}
          />
          {/* <TextInput
            ref={address => (this.address = address)}
            //keyboardType={'address-address'}
            autoCapitalize={'none'}
            autoCorrect={false}
            maxLength = {30}
            style={styles.input} 
            placeholder="กรอกที่อยู่ปัจจุบัน"
            onChangeText={address => this.setState({ address })}
            // keyboardType={'email-address'}

            // secureTextEntry={true}
          /> */}<View style={{marginTop:wp('3%')}}/>
             <Text style={styles.labelStyle}>ข้อมูลหมู่บ้านของคุณ</Text>
                  {/* <View style = {styles.lineStylew3} /> */}
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5 ,fontFamily: "Prompt-Light"}} >
                      เลือกจังหวัด
                  </FormLabel>
                  <Dropdown
                      containerStyle={{ fontFamily: "Prompt-Light",margin: 15,marginBottom: -10,  marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      fontFamily= "Prompt-Light"
                      ref={province => this.province = province}
                      data={this.state.getprovince}
                      onChangeText={
                          // province => this.setState({ province });
                          (itemValue, itemIndex) => this.getDistrict(itemValue)
                      }
                  />
                  <View style={this.state.hide ? {position: 'absolute', top: -200} : {}}>
                  <FormLabel labelStyle ={{ fontSize: 20, margin: 5 ,fontFamily: "Prompt-Light"}} >
                      เลือกอำเภอ
                  </FormLabel>
                  <Dropdown
                      containerStyle={{  fontFamily: "Prompt-Light" ,margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      fontFamily= "Prompt-Light"
                      ref={district => this.district = district}
                      data={this.state.getdistrict}
                      onChangeText={
                          (itemValue, itemIndex) => this.getSubDistrict(itemValue)
                      }
                  />
                  <FormLabel labelStyle ={{fontFamily: "Prompt-Light", fontSize: 20, margin: 5}} >
                      เลือกตำบล
                  </FormLabel>
                  <Dropdown
                      containerStyle={{  fontFamily: "Prompt-Light" ,margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      fontFamily= "Prompt-Light"
                      ref={subdistrict => this.subdistrict = subdistrict}
                      data={this.state.getsubdistrict}
                      onChangeText={
                          (itemValue, itemIndex) => this.getVillage(itemValue)
                      }
                  />
                  <FormLabel labelStyle ={{ fontFamily: "Prompt-Light" ,fontSize: 20, margin: 5}} >
                      เลือกหมู่บ้าน
                  </FormLabel>
                  <Dropdown
                      containerStyle={{  fontFamily: "Prompt-Light",margin: 15,marginBottom: -10,marginTop: -10 ,borderColor: 'grey', borderTop: 1 ,borderRadius: 5 }}
                      label=''
                      fontFamily= "Prompt-Light"
                      ref={village => this.village = village}
                      data={this.state.getvillage}
                      onChangeText={
                          village => this.setState({ village })
                      }
                  />
                  </View>
                  <View style = {styles.lineStylew3} />
                  
                  {/* <FormLabel labelStyle ={{ fontSize: 20, margin: 5}} >
                      7. เบอร์ติดต่อกลับ
                  </FormLabel>
                  <FormInput
                      inputStyle={{ borderColor: 'grey', marginTop: 5, borderWidth: 1 ,borderRadius: 5 }}
                      ref={email => this.email = email}
                      placeholder=''
                      onChangeText={
                          email => this.setState({ email })
                      }
                      keyboardType='email-address'
                  /> */}
                   {/* <Button
                        backgroundColor='#00802b'
                        buttonStyle={{ marginTop: 20, borderRadius: 5 }}
                        icon={{ name: 'camera', type: 'font-camera' }}
                        title='เพิ่มรูปภาพ'
                        onPress={this._SelectCameraRoll}
                    />
                    <View style={{alignItems:'center'}}>
                        { this.state.imageSource === null ? <Text></Text> :
                            <Image style={styles.avatar} source={this.state.imageSource} />
                        }
                    </View> */}
                  <View style={styles.setpositionbutton}>
                      <Button
                          backgroundColor='#00802b'
                          buttonStyle={{ marginTop: 30, width: 100, borderWidth: 1, borderColor: '#00802b' ,borderRadius: 5 ,marginLeft: -2.5 ,marginRight: -2.5}}
                          // icon={{ name: 'person', type: 'font-person' }}
                          title='ยืนยัน'
                          fontFamily= "Prompt-Light"
                          onPress={this._SaveUser}
                      />
                      <Button
                          backgroundColor='#ffff'
                          buttonStyle={{ marginTop: 30, width: 100, borderWidth: 1, borderColor: '#00802b' ,borderRadius: 5 ,marginLeft: -2.5 ,marginRight: -2.5}}
                          // icon={{ name: 'person', type: 'font-person' }}
                          title='ยกเลิก'
                          fontFamily= "Prompt-Light"
                          color="#00802b"
                          onPress={() => {
                              this.props.navigation.navigate("Home");
                          }}
                      />
                  </View>
                  
          
           <View style={{ flexDirection:'row' ,flex:1 ,justifyContent:'center' ,marginBottom:10}}>
          
         </View>

         </Card>

        </KeyboardAwareScrollView>

        </View>
              )}
          </View>
      );
  }
}






const styles = StyleSheet.create({
  container: {
    flex: 1,
    // marginTop: 10,
    // marginLeft: 10,
    backgroundColor: '#FFFFFF',
  },
  input: {
    height: 50,
    width: '90%',
    marginTop: 10,
    marginLeft:18,
    // marginBottom:10,
    padding: 4,
    borderRadius: 5,
    fontSize: 18,
    color:'#006600',
    borderWidth: 1,
    borderColor: '#48bbec33',
    fontFamily: "Prompt-Light"
},
labelStyle:{
  fontSize:18,
  color:'#006600',
  marginLeft:20,
  marginTop:10,
  fontFamily: "Prompt-Light"
},

welcome: {
  fontSize: 20,
  textAlign: 'center',
  margin: 15,
  marginBottom: -20,
  color: '#00802b',
  fontFamily: "Prompt-Light"
},
setpositionbutton: {
  // flex:1,
  flexDirection:'row',
  alignItems:'center',
  marginTop: -10,
  margin: 20,
  justifyContent:'center',
},
setpositiontextafterbutton: {
  flex: .2,
  flexDirection:'row',
  fontSize: 26,
  textAlign: 'center',
  marginTop: 45,
  marginBottom: 45,
  color: '#00802b',
},
setpositiontextbeforebutton: {
  flexDirection:'row',
  fontSize: 20,
  textAlign: 'center',
  margin: 20,
  color: '#00802b',
},
lineStyleh:{
  borderWidth: 0.5,
  borderColor:'#9B9B9B',
  margin: 15,
  marginTop: -2,  
  height: 250
},
lineStylew1:{
  borderWidth: 1,
  borderColor:'#00802b',
  backgroundColor: '#00802b',
  marginTop: 40,  
  width,
},
lineStylew2:{
  borderWidth: 2,
  borderColor:'#00802b',
  backgroundColor: '#00802b',
  marginTop: 3,  
  width,
},
lineStylew3:{
  borderWidth: 0.5,
  borderColor:'#9B9B9B',
  backgroundColor: '#9B9B9B',
  marginTop: 20,  
  alignSelf: 'center',
  width: '93%',
},
button: {
  margin: 10,
  marginTop: -50,
  height: 160,
  width: 160,
  alignItems: 'center',
  backgroundColor: '#A5E65A',
  borderRadius: 80,
},
buttonText: {
  padding: 40,
  color: 'white'
},
avatar: {
    //borderRadius: 75,
    margin: 10,
    marginLeft: 15,
    width: 150,
    height: 150
  }
});